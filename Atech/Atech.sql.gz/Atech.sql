-- phpMyAdmin SQL Dump
-- version 2.11.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 16, 2008 at 01:03 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `Atech`
--

-- --------------------------------------------------------

--
-- Table structure for table `Item`
--

CREATE TABLE IF NOT EXISTS `Item` (
  `ItemNo` int(11) NOT NULL,
  `Name` varchar(100) default NULL,
  `Price` double default NULL,
  `Quantity` int(11) default NULL,
  `SupplierNo` int(11) NOT NULL,
  PRIMARY KEY  (`ItemNo`),
  UNIQUE KEY `ItemNo` (`ItemNo`),
  KEY `SupplierNo` (`SupplierNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Item`
--

INSERT INTO `Item` (`ItemNo`, `Name`, `Price`, `Quantity`, `SupplierNo`) VALUES
(1, 'ASUS Computers', 2000, 5, 1),
(2, 'Penasonic Stand Fan', 100, 9, 1),
(3, 'Sony Washing Machine', 500, 9, 1),
(4, 'HP Printer', 500, 8, 1),
(5, 'Sugus Television', 489, 0, 1),
(6, 'Sugus Plasma Television', 1999.9, 5, 1),
(7, 'Asus Laser Mouse', 15, 17, 1),
(8, 'Sony 5.0 Megapixels Camera', 899, 4, 1),
(9, 'Penasonic Keyboard', 38.5, 12, 1),
(10, 'Icentury Mouse Pad', 3.8, 34, 1),
(11, 'Black Modem', 185, 8, 2),
(12, 'White Modem Cable 25metres', 25, 12, 2),
(13, 'Pink Wireless Modem ', 160, 15, 2),
(14, 'Gold X99 Wireless Modem Router', 205, 6, 2),
(15, 'Red V8 Radio', 156, 4, 2),
(16, 'Blue Scanner', 178, 3, 2),
(17, 'Grey LCD Monitor 19''', 780, 9, 2),
(18, 'Brown LCD Monitor 17''', 599, 6, 2),
(19, 'Green Wireless Adaptor 2.0mb', 90, 24, 2),
(20, 'Purple CRT Monitor 24''', 600, 1, 2),
(21, 'Invisible AirCond', 2500, 13, 3),
(22, 'Atech Power Trap', 2500, 1, 3),
(23, 'AAA Battery', 3.8, 1000, 3),
(24, 'Halicopter(toy)', 95, 50, 3),
(25, 'LCD LG', 2500, 25, 3),
(26, 'Cupboard', 123, 10, 4),
(27, 'Table', 56, 8, 4),
(28, 'Chair', 10, 1, 4),
(29, 'File', 0.6, 120, 5),
(30, 'Laptop', 5000, 5, 5),
(31, 'HandPhone', 1566, 5, 5),
(32, 'PaperCut', 12, 9, 6),
(33, 'Mahamaju', 13, 4, 6),
(34, 'Ghany Corner', 14, 8, 6),
(35, 'U Beauty', 16, 7, 7),
(36, 'UTAR', 0.8, 4, 7),
(37, 'KTAR', 1.5, 5, 8),
(38, 'KITKAT', 1.8, 120, 8),
(39, 'Pokemon', 500, 21, 8),
(40, 'Digimon', 800, 51, 9),
(41, 'Sailormoon', 859, 3, 9),
(42, 'Pikachu', 12, 1, 10),
(43, 'Boot Of Travel', 2700, 1, 10),
(44, 'Monkey King Bar', 5800, 5, 10),
(45, 'Black King Bar', 38, 4, 8),
(46, 'Bracer', 350, 7, 9),
(47, 'Mask Of Madness', 90, 51, 7),
(48, 'Sobi Mask', 350, 8, 7),
(49, 'Divine Rapier', 7800, 1, 8),
(50, 'Butterfly', 1, 38, 9);

-- --------------------------------------------------------

--
-- Table structure for table `OrderItem`
--

CREATE TABLE IF NOT EXISTS `OrderItem` (
  `OrderNo` int(11) NOT NULL,
  `ItemNo` int(11) NOT NULL,
  `Quantity` int(11) default NULL,
  `Cost` double default NULL,
  PRIMARY KEY  (`OrderNo`,`ItemNo`),
  KEY `ItemNo` (`ItemNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `OrderItem`
--

INSERT INTO `OrderItem` (`OrderNo`, `ItemNo`, `Quantity`, `Cost`) VALUES
(1, 1, 1, 1),
(1, 2, 1, 1),
(1, 4, 1, 1),
(1, 5, 1, 1),
(2, 1, 2, 1),
(2, 4, 2, 2),
(2, 6, 2, 1),
(2, 7, 2, 1),
(2, 8, 2, 1),
(3, 13, 10, 10),
(3, 14, 10, 10),
(3, 16, 10, 10),
(3, 18, 10, 10),
(3, 20, 10, 10),
(4, 21, 10, 10),
(5, 11, 1, 1),
(5, 12, 1, 1),
(5, 13, 1, 1),
(5, 14, 1, 1),
(5, 15, 1, 1),
(5, 16, 1, 1),
(5, 17, 1, 1),
(5, 18, 1, 1),
(5, 19, 1, 1),
(5, 20, 1, 1),
(6, 2, 1, 1),
(7, 12, 1, 1),
(8, 12, 1, 1),
(9, 2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Order_Invoice`
--

CREATE TABLE IF NOT EXISTS `Order_Invoice` (
  `OrderNo` int(11) NOT NULL,
  `SupplierNo` int(11) NOT NULL,
  `Total` double default NULL,
  `Delivered` datetime default NULL,
  `Paid` datetime default NULL,
  PRIMARY KEY  (`OrderNo`),
  UNIQUE KEY `OrderNo` (`OrderNo`),
  KEY `SupplierNo` (`SupplierNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Order_Invoice`
--

INSERT INTO `Order_Invoice` (`OrderNo`, `SupplierNo`, `Total`, `Delivered`, `Paid`) VALUES
(1, 1, 4, '2008-04-15 20:08:14', '2008-04-15 20:08:22'),
(2, 1, 12, '2008-04-15 22:50:55', '2008-04-15 22:51:17'),
(3, 2, 500, '2008-04-15 22:51:27', '2008-04-15 22:51:38'),
(4, 3, 100, '2008-04-15 22:56:17', NULL),
(5, 2, 10, NULL, NULL),
(6, 1, 1, NULL, NULL),
(7, 2, 1, NULL, NULL),
(8, 2, 1, '2008-04-16 00:20:03', NULL),
(9, 1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `SalesItem`
--

CREATE TABLE IF NOT EXISTS `SalesItem` (
  `SalesNo` int(11) NOT NULL,
  `ItemNo` int(11) NOT NULL,
  `Quantity` int(11) default NULL,
  PRIMARY KEY  (`ItemNo`,`SalesNo`),
  KEY `SalesNo` (`SalesNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SalesItem`
--

INSERT INTO `SalesItem` (`SalesNo`, `ItemNo`, `Quantity`) VALUES
(1, 1, 1),
(2, 1, 1),
(3, 1, 1),
(1, 2, 1),
(6, 3, 1),
(1, 4, 1),
(4, 5, 1),
(5, 5, 2),
(7, 7, 3),
(1, 9, 1),
(8, 10, 2),
(9, 10, 10),
(10, 10, 2),
(11, 10, 2),
(1, 12, 1),
(1, 18, 1),
(1, 20, 1);

-- --------------------------------------------------------

--
-- Table structure for table `SalesRecord`
--

CREATE TABLE IF NOT EXISTS `SalesRecord` (
  `SalesNo` int(11) NOT NULL,
  `Total` double default NULL,
  `Date` datetime default NULL,
  PRIMARY KEY  (`SalesNo`),
  UNIQUE KEY `SalesNo` (`SalesNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SalesRecord`
--

INSERT INTO `SalesRecord` (`SalesNo`, `Total`, `Date`) VALUES
(1, 3862.5, '2008-04-15 19:52:14'),
(2, 2000, '2008-04-15 19:52:23'),
(3, 2000, '2008-04-15 19:53:58'),
(4, 489, '2008-04-15 19:54:07'),
(5, 978, '2008-04-15 19:54:22'),
(6, 500, '2008-04-15 19:54:37'),
(7, 45, '2008-04-15 19:54:50'),
(8, 7.6, '2008-04-15 19:55:08'),
(9, 38, '2008-04-15 19:55:30'),
(10, 7.6, '2008-04-15 23:35:33'),
(11, 7.6, '2008-04-15 23:39:16');

-- --------------------------------------------------------

--
-- Table structure for table `Supplier`
--

CREATE TABLE IF NOT EXISTS `Supplier` (
  `SupplierNo` int(11) NOT NULL,
  `SupplierName` varchar(100) default NULL,
  `ContactNo` varchar(100) default NULL,
  `Address` varchar(100) default NULL,
  PRIMARY KEY  (`SupplierNo`),
  UNIQUE KEY `SupplierNo` (`SupplierNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Supplier`
--

INSERT INTO `Supplier` (`SupplierNo`, `SupplierName`, `ContactNo`, `Address`) VALUES
(1, 'Chong Yoe Yat Sdn Bhd', '0177939038', '2382 A1. Jalan Kolej, Tmn Kolej, 31600. Kampar. Perak.'),
(2, 'Chow Kah Leong Sdn Bhd', '0125190381', '2382 A2, Jalan kolej, Tmn Kolej, 31600. Kampar. Perak.'),
(3, 'Chin Yik Soon Sdn Bhd', '0165354350', '2364 A3, Jalan GC, Taman Kolej, 31600. Kampar. Perak'),
(4, 'Soo Weng Loon Sdn Bhd', '0165186337', '2364 A3,Jalan GC, Taman Kolej, 31600. Kampar. Perak'),
(5, 'Wong Chun How Sdn Bhd', '0174171470', '2364 A2, Jalan GC, Taman Kolej, 31600. Kampar. Perak'),
(6, 'Yip Wai Lam  Sdn Bhd', '0165515198', '2364 A2, Jalan GC, Taman Kolej, 31600. Kampar. Perak'),
(7, 'John Leong Sdn Bhd', '0165992699', '2364 A1,  jalan GC, Taman Kolej, 31600. Kampar. Perak'),
(8, 'StarHill Ltd', '03333555555', '1, Jalan Bukit Bintang, Bukit Bintang. 50000, Bukit Bintang.  Selangor.'),
(9, 'Ghany Bhd', '054774774', '1, Jalan Ghany, Taman Ghany. 31600. Ghany, Perak.'),
(10, 'MahaMaju Bhd', '057747747', '1, Jalan MahaMaju, Taman MM, 31600. Maha Perak.');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Item`
--
ALTER TABLE `Item`
  ADD CONSTRAINT `Item_ibfk_1` FOREIGN KEY (`SupplierNo`) REFERENCES `Supplier` (`SupplierNo`) ON UPDATE CASCADE;

--
-- Constraints for table `OrderItem`
--
ALTER TABLE `OrderItem`
  ADD CONSTRAINT `OrderItem_ibfk_1` FOREIGN KEY (`OrderNo`) REFERENCES `Order_Invoice` (`OrderNo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `OrderItem_ibfk_2` FOREIGN KEY (`ItemNo`) REFERENCES `Item` (`ItemNo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Order_Invoice`
--
ALTER TABLE `Order_Invoice`
  ADD CONSTRAINT `Order_Invoice_ibfk_1` FOREIGN KEY (`SupplierNo`) REFERENCES `Supplier` (`SupplierNo`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `SalesItem`
--
ALTER TABLE `SalesItem`
  ADD CONSTRAINT `SalesItem_ibfk_1` FOREIGN KEY (`ItemNo`) REFERENCES `Item` (`ItemNo`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `SalesItem_ibfk_2` FOREIGN KEY (`SalesNo`) REFERENCES `SalesRecord` (`SalesNo`) ON DELETE CASCADE ON UPDATE CASCADE;
